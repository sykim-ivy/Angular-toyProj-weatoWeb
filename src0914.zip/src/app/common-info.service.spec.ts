import { TestBed, inject } from '@angular/core/testing';

import { CommonInfoService } from './common-info.service';

describe('CommonInfoService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CommonInfoService]
    });
  });

  it('should be created', inject([CommonInfoService], (service: CommonInfoService) => {
    expect(service).toBeTruthy();
  }));
});
