import { TestBed, inject } from '@angular/core/testing';

import { HttpRequestInputdataService } from './http-request-inputdata.service';

describe('HttpRequestInputdataService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [HttpRequestInputdataService]
    });
  });

  it('should be created', inject([HttpRequestInputdataService], (service: HttpRequestInputdataService) => {
    expect(service).toBeTruthy();
  }));
});
