import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
// component
import { AppComponent } from './app.component';
import { SearchResultComponent } from './search-result/search-result.component';
import { MainPageComponent } from './main-page/main-page.component';
// resolver
import { MoveResultpageResolver } from './main-page/move-resultpage.resolver';

const routes: Routes = [ 
    { path: '', redirectTo: '/main', pathMatch: 'full' },
    { path: 'main',  component: MainPageComponent },
    // { path: 'result',  component: SearchResultComponent }
    { path: 'result',  component: SearchResultComponent, resolve : {result : MoveResultpageResolver} }
];

@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule {}


/*
Copyright 2017 Google Inc. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://angular.io/license
*/